@php
    use Illuminate\Support\Str;
@endphp

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'SiTahu Premium - Tahu Segar Berkualitas')</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root {
            /* Brand Colors */
            --brand-color: #c89335;
            --brand-hover: #b5822b;
            --brand-soft: #fefcf7;
            
            /* Text & Backgrounds */
            --text-main: #1f2937;
            --text-muted: #6b7280;
            --bg-body: #f8fafc;
            --border-light: #e5e7eb;
            
            /* Shadows */
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.02);
            --shadow-md: 0 10px 15px -3px rgba(0,0,0,0.05);
        }
        html {
            overflow-y: scroll; /* Fallback untuk browser lama */
            scrollbar-gutter: stable; /* Standar modern untuk mencegah layout shift */
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
}
        /* Top Announcement Bar */
        .top-bar {
            background-color: var(--text-main);
            color: #ffffff;
            font-size: 12px;
            font-weight: 500;
            letter-spacing: 0.02em;
        }

        /* Glassmorphism Navbar */
        .navbar-premium {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(229, 231, 235, 0.5);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02);
            transition: all 0.3s ease;
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-logo-box {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--brand-color), var(--brand-hover));
            color: white;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 18px;
            box-shadow: 0 4px 10px rgba(200, 147, 53, 0.3);
        }

        .nav-link {
            font-weight: 600;
            color: var(--text-muted) !important;
            padding: 8px 16px !important;
            border-radius: 8px;
            transition: all 0.2s ease;
            font-size: 14.5px;
        }

        .nav-link:hover, .nav-link.active {
            color: var(--brand-color) !important;
            background-color: var(--brand-soft);
        }

        /* Action Buttons (Cart, User) */
        .nav-action-btn {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: var(--bg-body);
            color: var(--text-main);
            text-decoration: none;
            transition: all 0.2s ease;
            border: 1px solid transparent;
            position: relative;
        }

        .nav-action-btn:hover {
            background-color: var(--brand-soft);
            color: var(--brand-color);
            border-color: var(--brand-color);
        }

        .cart-badge {
            position: absolute;
            top: 0;
            right: 0;
            width: 18px;
            height: 18px;
            background-color: #ef4444;
            color: white;
            border-radius: 50%;
            font-size: 10px;
            font-weight: 800;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
        }

        /* Main Content Wrapper */
        .main-content {
            flex: 1;
            padding-top: 1.5rem;
            padding-bottom: 3rem;
        }

        /* Premium Footer */
        .footer-premium {
            background-color: #ffffff;
            border-top: 1px solid var(--border-light);
            padding: 4rem 0 2rem;
            margin-top: auto;
        }

        .footer-title {
            font-size: 16px;
            font-weight: 800;
            color: var(--text-main);
            margin-bottom: 1.5rem;
            letter-spacing: -0.01em;
        }

        .footer-link {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 14px;
            transition: color 0.2s ease;
            display: block;
            margin-bottom: 0.75rem;
        }

        .footer-link:hover {
            color: var(--brand-color);
        }

        /* Dropdown Custom */
        .dropdown-menu {
            border: none;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);
            border-radius: 12px;
            padding: 10px;
        }
        .dropdown-item {
            border-radius: 8px;
            font-weight: 500;
            font-size: 14px;
            padding: 8px 16px;
        }
        .dropdown-item:hover {
            background-color: var(--brand-soft);
            color: var(--brand-color);
        }
    </style>

    @stack('styles')
</head>

<body>
    
    <div class="top-bar py-2 d-none d-lg-block">
        <div class="container d-flex justify-content-between align-items-center">
            <span><i class="bi bi-truck me-2"></i> Pengiriman aman ke seluruh area jangkauan | 100% Kedelai Pilihan</span>
            <div class="d-flex gap-4">
                <span><i class="bi bi-headset me-1"></i> Layanan Pelanggan</span>
                <span><i class="bi bi-shield-check me-1"></i> Garansi Kualitas</span>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-premium sticky-top py-2">
        <div class="container">
            <a class="navbar-brand text-decoration-none" href="{{ route('pembeli-web.home') }}">
                <div class="brand-logo-box">ST</div>
                <div>
                    <h1 class="m-0 fs-5 fw-bolder text-dark" style="letter-spacing: -0.03em;">SiTahu</h1>
                </div>
            </a>

            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-expanded="false">
                <i class="bi bi-list fs-1 text-dark"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-1 mt-3 mt-lg-0 text-center">
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('pembeli-web.home') ? 'active' : '' }}" href="{{ route('pembeli-web.home') }}">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('pembeli-web.produk') || request()->routeIs('pembeli-web.produk.detail') ? 'active' : '' }}" href="{{ route('pembeli-web.produk') }}">Produk Kami</a>
                    </li>
                    
                    @auth
                        @if(auth()->user()->role === 'pembeli')
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('pembeli-web.pesanan.*') ? 'active' : '' }}" href="{{ route('pembeli-web.pesanan.index') }}">Pesanan Saya</a>
                            </li>
                        @endif
                    @endauth
                </ul>

                <div class="d-flex align-items-center justify-content-center gap-2 mt-3 mt-lg-0">
                    
                    @auth
                        @if(auth()->user()->role === 'pembeli')
                            <a href="{{ route('pembeli-web.keranjang.index') }}" class="nav-action-btn" title="Keranjang">
                                <i class="bi bi-bag fs-5"></i>
                                <span class="cart-badge">!</span> 
                            </a>

                            <div class="dropdown">
                                <a href="#" class="nav-action-btn ms-1" data-bs-toggle="dropdown" aria-expanded="false" title="Profil">
                                    <i class="bi bi-person fs-5"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end mt-2 border-0 shadow-lg">
                                    <li><h6 class="dropdown-header fw-bold text-dark px-3 py-2">Halo, {{ Str::limit(auth()->user()->name, 15) }}</h6></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="{{ route('pembeli-web.profil') }}"><i class="bi bi-person-circle me-2"></i> Profil Saya</a></li>
                                    <li><a class="dropdown-item" href="{{ route('pembeli-web.alamat.index') }}"><i class="bi bi-geo-alt me-2"></i> Daftar Alamat</a></li>
                                    <li>
                                        <form action="{{ route('pembeli-web.logout') }}" method="POST">
                                            @csrf
                                            <button type="submit" class="dropdown-item text-danger mt-1"><i class="bi bi-box-arrow-right me-2"></i> Keluar</button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        @else
                            <span class="badge bg-warning text-dark me-2">Admin Mode</span>
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button type="submit" class="btn btn-sm border-secondary text-dark rounded-pill fw-bold px-3">Logout Admin</button>
                            </form>
                        @endif
                    @else
                        <a href="{{ route('pembeli-web.login') }}" class="btn text-dark fw-bold px-3">Masuk</a>
                        <a href="{{ route('pembeli-web.register') }}" class="btn text-white fw-bold px-4 rounded-pill" style="background-color: var(--brand-color);">Daftar</a>
                    @endauth

                </div>
            </div>
        </div>
    </nav>

    <main class="main-content">
        @yield('content')
    </main>

    <footer class="footer-premium">
        <div class="container">
            <div class="row g-4 mb-5">
                
                <div class="col-lg-4 pe-lg-5 text-center text-lg-start">
                    <div class="navbar-brand justify-content-center justify-content-lg-start mb-3">
                        <div class="brand-logo-box">ST</div>
                        <h2 class="m-0 fs-4 fw-bolder text-dark">SiTahu Premium</h2>
                    </div>
                    <p class="text-muted fs-6" style="line-height: 1.6;">
                        Berkomitmen menyajikan produk olahan kedelai terbaik dengan standar kebersihan tinggi dan tanpa bahan pengawet. Segar dari pabrik ke meja makan Anda setiap hari.
                    </p>
                    <div class="d-flex gap-3 mt-4 justify-content-center justify-content-lg-start">
                        <a href="#" class="nav-action-btn bg-light"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="nav-action-btn bg-light"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="nav-action-btn bg-light"><i class="bi bi-whatsapp"></i></a>
                    </div>
                </div>

                <div class="col-6 col-lg-2 offset-lg-1">
                    <h4 class="footer-title">Layanan</h4>
                    <a href="{{ route('pembeli-web.home') }}" class="footer-link">Beranda</a>
                    <a href="{{ route('pembeli-web.produk') }}" class="footer-link">Semua Produk</a>
                    <a href="#" class="footer-link">Cara Pesan</a>
                    <a href="#" class="footer-link">Tanya Jawab (FAQ)</a>
                </div>

                <div class="col-6 col-lg-2">
                    <h4 class="footer-title">Akun Saya</h4>
                    @auth
                        @if(auth()->user()->role === 'pembeli')
                            <a href="{{ route('pembeli-web.profil') }}" class="footer-link">Profil Saya</a>
                            <a href="{{ route('pembeli-web.pesanan.index') }}" class="footer-link">Lacak Pesanan</a>
                            <a href="{{ route('pembeli-web.keranjang.index') }}" class="footer-link">Keranjang</a>
                        @endif
                    @else
                        <a href="{{ route('pembeli-web.login') }}" class="footer-link">Masuk</a>
                        <a href="{{ route('pembeli-web.register') }}" class="footer-link">Daftar Akun Baru</a>
                    @endauth
                </div>

                <div class="col-lg-3 text-center text-lg-start mt-4 mt-lg-0">
                    <h4 class="footer-title">Hubungi Kami</h4>
                    <div class="d-flex align-items-center justify-content-center justify-content-lg-start mb-3">
                        <i class="bi bi-geo-alt fs-5 text-brand me-3" style="color: var(--brand-color);"></i>
                        <span class="text-muted" style="font-size: 14px;">Produksi Langsung di Pabrik Kami.</span>
                    </div>
                    <div class="d-flex align-items-center justify-content-center justify-content-lg-start mb-3">
                        <i class="bi bi-clock fs-5 text-brand me-3" style="color: var(--brand-color);"></i>
                        <span class="text-muted" style="font-size: 14px;">Buka Setiap Hari (06:00 - 18:00)</span>
                    </div>
                </div>

            </div>

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center pt-4 border-top" style="border-color: var(--border-light) !important;">
                <p class="text-muted mb-0" style="font-size: 13px;">&copy; {{ date('Y') }} SiTahu Premium. Hak Cipta Dilindungi.</p>
                <div class="d-flex gap-3 mt-2 mt-md-0">
                    <span class="text-muted" style="font-size: 13px;">Kualitas & Kebersihan Terjamin.</span>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    @stack('scripts')
</body>
</html>