@extends('layouts.pembeli')

@section('title', 'Katalog Produk - SiTahu Premium')

@push('styles')
<style>
    /* =========================================
     * PREMIUM PRODUCT CATALOG UI
     * Selaras dengan Beranda, Login & Register
     * ========================================= */
    
    /* Hero Banner Mini */
    .catalog-hero {
        background: linear-gradient(135deg, var(--brand-soft) 0%, #ffffff 100%);
        border: 1px solid var(--border-light);
        border-radius: 1.25rem;
        padding: 2.5rem 3rem;
        position: relative;
        overflow: hidden;
    }

    .catalog-hero::after {
        content: "";
        position: absolute;
        top: -50px;
        right: -50px;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(200, 147, 53, 0.15) 0%, rgba(255,255,255,0) 70%);
        pointer-events: none;
    }

    /* Filter & Search Bar */
    .filter-card {
        background: #ffffff;
        border: 1px solid var(--border-light);
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02);
        padding: 1.5rem;
        margin-top: -2rem; /* Overlapping hero slightly for modern look */
        position: relative;
        z-index: 10;
    }

    .form-label-custom {
        font-size: 12.5px;
        font-weight: 700;
        color: var(--text-main);
        margin-bottom: 6px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .input-custom {
        border-radius: 10px;
        border: 1px solid #e5e7eb;
        padding: 0.6rem 1rem;
        font-size: 14px;
        font-weight: 500;
        background-color: #f8fafc;
        transition: all 0.2s ease;
    }

    .input-custom:focus {
        background-color: #ffffff;
        border-color: var(--brand-color);
        box-shadow: 0 0 0 3px rgba(200, 147, 53, 0.15);
        outline: none;
    }

    /* Product Card Modern */
    .product-card {
        border: 1px solid #edf2f7;
        border-radius: 1.25rem;
        background: #ffffff;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        overflow: hidden;
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    .product-card:hover {
        border-color: #e2e8f0;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
        transform: translateY(-6px);
    }

    .product-img-wrapper {
        position: relative;
        width: 100%;
        padding-top: 100%; /* 1:1 Aspect Ratio */
        background: #f1f5f9;
        overflow: hidden;
    }

    .product-img-wrapper img {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .product-card:hover .product-img-wrapper img {
        transform: scale(1.08); /* Efek zoom elegan */
    }

    /* Badges / Lencana */
    .status-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        padding: 4px 12px;
        border-radius: 50rem;
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 0.03em;
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        z-index: 2;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .badge-ready {
        background: rgba(255, 255, 255, 0.9);
        color: #15803d;
        border: 1px solid rgba(21, 128, 61, 0.2);
    }

    .badge-empty {
        background: rgba(254, 242, 242, 0.95);
        color: #b91c1c;
        border: 1px solid rgba(185, 28, 28, 0.2);
    }

    /* Pill Meta Info (Berat/Satuan) */
    .meta-pill {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 6px;
        background: #f8fafc;
        border: 1px solid #edf2f7;
        color: var(--text-muted);
        font-size: 11.5px;
        font-weight: 600;
        margin-right: 4px;
        margin-bottom: 6px;
    }

    /* Buttons */
    .btn-action-primary {
        background-color: var(--brand-color);
        color: white;
        font-weight: 700;
        border-radius: 10px;
        font-size: 13.5px;
        padding: 8px 0;
        transition: all 0.2s;
        border: none;
        width: 100%;
    }
    .btn-action-primary:hover {
        background-color: var(--brand-hover);
        color: white;
    }

    .btn-action-outline {
        background-color: transparent;
        color: var(--brand-color);
        font-weight: 700;
        border-radius: 10px;
        font-size: 13.5px;
        padding: 8px 0;
        transition: all 0.2s;
        border: 1px solid var(--brand-color);
        width: 100%;
        text-align: center;
        text-decoration: none;
    }
    .btn-action-outline:hover {
        background-color: var(--brand-soft);
        color: var(--brand-hover);
    }

    .btn-action-disabled {
        background-color: #f3f4f6;
        color: #9ca3af;
        font-weight: 700;
        border-radius: 10px;
        font-size: 13.5px;
        padding: 8px 0;
        border: 1px solid #e5e7eb;
        width: 100%;
        cursor: not-allowed;
    }

    /* Empty State */
    .empty-state-box {
        text-align: center;
        padding: 4rem 2rem;
        background: #ffffff;
        border: 1px dashed #cbd5e1;
        border-radius: 1.5rem;
    }
    .empty-state-icon {
        width: 64px;
        height: 64px;
        background: var(--brand-soft);
        color: var(--brand-color);
        border-radius: 1rem;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.75rem;
        margin-bottom: 1.5rem;
    }

    @media (max-width: 768px) {
        .catalog-hero { padding: 2rem 1.5rem; }
        .filter-card { margin-top: 1rem; }
    }
</style>
@endpush

@section('content')
<div class="container py-4">

    <div class="catalog-hero mb-4">
        <div class="position-relative z-2">
            <span class="badge bg-white text-brand border px-3 py-2 rounded-pill fw-bold mb-3" style="font-size: 11.5px; color: var(--brand-color); border-color: rgba(200, 147, 53, 0.3) !important;">
                <i class="bi bi-shop me-1"></i> Etalase Resmi
            </span>
            <h1 class="fw-bolder text-dark mb-2" style="font-size: clamp(28px, 4vw, 42px); letter-spacing: -0.03em;">
                Koleksi Lengkap Tahu Segar.
            </h1>
            <p class="text-muted m-0" style="font-size: 15px; max-width: 600px; line-height: 1.6;">
                Temukan varian produk olahan kedelai terbaik yang diproduksi setiap hari untuk memenuhi kebutuhan hidangan dan gizi keluarga Anda.
            </p>
        </div>
    </div>

    <div class="filter-card mb-4 mb-lg-5">
        <form action="{{ route('pembeli-web.produk') }}" method="GET">
            <div class="row g-3 align-items-end">
                
                <div class="col-12 col-lg-5">
                    <label for="search" class="form-label-custom">Cari Produk</label>
                    <div class="position-relative">
                        <i class="bi bi-search position-absolute text-muted" style="top: 50%; transform: translateY(-50%); left: 14px;"></i>
                        <input type="text" id="search" name="search" class="form-control input-custom" style="padding-left: 38px;" value="{{ $search }}" placeholder="Contoh: Tahu Putih, Bakso Tahu...">
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <label for="sort" class="form-label-custom">Urutkan Berdasarkan</label>
                    <select id="sort" name="sort" class="form-select input-custom">
                        <option value="terbaru" {{ $sort === 'terbaru' ? 'selected' : '' }}>Paling Baru</option>
                        <option value="termurah" {{ $sort === 'termurah' ? 'selected' : '' }}>Harga Terendah</option>
                        <option value="termahal" {{ $sort === 'termahal' ? 'selected' : '' }}>Harga Tertinggi</option>
                        <option value="stok_banyak" {{ $sort === 'stok_banyak' ? 'selected' : '' }}>Stok Terbanyak</option>
                        <option value="nama" {{ $sort === 'nama' ? 'selected' : '' }}>Alfabet (A-Z)</option>
                    </select>
                </div>

                <div class="col-6 col-lg-2">
                    <label for="stok" class="form-label-custom">Ketersediaan</label>
                    <select id="stok" name="stok" class="form-select input-custom">
                        <option value="semua" {{ $stok === 'semua' ? 'selected' : '' }}>Semua Produk</option>
                        <option value="tersedia" {{ $stok === 'tersedia' ? 'selected' : '' }}>Stok Tersedia</option>
                        <option value="habis" {{ $stok === 'habis' ? 'selected' : '' }}>Stok Habis</option>
                    </select>
                </div>

                <div class="col-12 col-lg-2">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-brand-pill flex-grow-1" style="background-color: var(--brand-color); color: white; border: none; border-radius: 10px; font-weight: 700; font-size: 14px; padding: 0.6rem 1rem;">
                            Terapkan
                        </button>
                        @if($search || $sort !== 'terbaru' || $stok !== 'semua')
                            <a href="{{ route('pembeli-web.produk') }}" class="btn btn-light" style="border-radius: 10px; padding: 0.6rem 1rem; border: 1px solid #e5e7eb;" title="Reset Filter">
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </a>
                        @endif
                    </div>
                </div>

            </div>
        </form>
    </div>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 pb-2 border-bottom">
        <div class="text-muted" style="font-size: 14.5px;">
            Menampilkan <strong class="text-dark">{{ $produkList->count() }}</strong> dari <strong class="text-dark">{{ $produkList->total() }}</strong> produk.
            @if($search)
                Hasil pencarian untuk <strong class="text-dark">"{{ $search }}"</strong>.
            @endif
        </div>
    </div>

    @if($produkList->count())
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-3 g-lg-4 mb-5">
            @foreach($produkList as $produk)
                @php
                    $gambar = $produk->gambarUtama?->url_gambar;
                    $deskripsi = $produk->deskripsi
                        ? \Illuminate\Support\Str::limit(strip_tags($produk->deskripsi), 65)
                        : 'Produk olahan kedelai segar yang kaya protein untuk harian.';
                    $stokTersedia = (int) $produk->stok > 0;
                @endphp

                <div class="col">
                    <div class="product-card">
                        
                        <div class="product-img-wrapper">
                            @if($stokTersedia)
                                <span class="status-badge badge-ready"><i class="bi bi-check2-circle me-1"></i> Tersedia</span>
                            @else
                                <span class="status-badge badge-empty"><i class="bi bi-x-circle me-1"></i> Habis</span>
                            @endif

                            @if($gambar)
                                <img src="{{ asset('storage/' . $gambar) }}" alt="{{ $produk->nama }}">
                            @else
                                <div class="d-flex align-items-center justify-content-center h-100 w-100 text-muted fw-bold" style="font-size: 12px; position: absolute; background: #f8fafc;">
                                    NO IMAGE
                                </div>
                            @endif
                        </div>

                        <div class="p-3 d-flex flex-column flex-grow-1">
                            <h2 class="text-dark fw-bold mb-1" style="font-size: 15.5px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                {{ $produk->nama }}
                            </h2>
                            <p class="text-muted mb-2" style="font-size: 12.5px; line-height: 1.5; min-height: 38px;">
                                {{ $deskripsi }}
                            </p>

                            <div class="mb-3">
                                <span class="meta-pill">{{ $produk->satuan ?: 'Satuan' }}</span>
                                @if($produk->isi_per_satuan) <span class="meta-pill">Isi {{ $produk->isi_per_satuan }}</span> @endif
                                @if($produk->berat) <span class="meta-pill">{{ number_format($produk->berat, 0, ',', '.') }}gr</span> @endif
                                <span class="meta-pill">Stok {{ $produk->stok }}</span>
                            </div>

                            <div class="mt-auto">
                                <div class="fw-bolder mb-3" style="font-size: 18px; color: var(--text-main);">
                                    Rp {{ number_format($produk->harga, 0, ',', '.') }}
                                </div>

                                <div class="row g-2">
                                    <div class="col-6">
                                        <a href="{{ route('pembeli-web.produk.detail', $produk) }}" class="btn-action-outline d-block">
                                            Detail
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        @if($stokTersedia)
                                            <form action="{{ route('pembeli-web.keranjang.store', $produk) }}" method="POST" class="m-0">
                                                @csrf
                                                <input type="hidden" name="jumlah" value="1">
                                                <button type="submit" class="btn-action-primary shadow-sm" title="Tambah ke Keranjang">
                                                    + Keranjang
                                                </button>
                                            </form>
                                        @else
                                            <button type="button" class="btn-action-disabled" disabled>
                                                Kosong
                                            </button>
                                        @endif
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="d-flex justify-content-center mt-4">
            {{ $produkList->links('pagination::bootstrap-5') }}
        </div>

    @else
        <div class="empty-state-box my-5 shadow-sm">
            <div class="empty-state-icon">
                <i class="bi bi-search"></i>
            </div>
            <h3 class="fw-bolder text-dark mb-2" style="font-size: 22px; letter-spacing: -0.02em;">Produk Belum Ditemukan</h3>
            <p class="text-muted mb-4 mx-auto" style="font-size: 15px; max-width: 450px; line-height: 1.6;">
                Maaf, kami tidak dapat menemukan produk yang sesuai dengan filter atau kata kunci pencarian Anda. Silakan coba kata kunci lain.
            </p>
            <a href="{{ route('pembeli-web.produk') }}" class="btn btn-brand-pill px-4" style="background-color: var(--brand-color); color: white; border-radius: 50rem; font-weight: 700; text-decoration: none;">
                Reset Pencarian & Filter
            </a>
        </div>
    @endif

</div>
@endsection