@extends('layouts.pembeli')

@section('title', 'Masuk ke Akun - SiTahu Premium')

@push('styles')
<style>
    /* =========================================
     * PREMIUM & UNIFORM LOGIN UI
     * 100% Selaras dengan tema Beranda (Clean & Airy)
     * ========================================= */
    .auth-container {
        min-height: calc(100vh - 200px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 3rem 1rem;
    }

    .auth-card-premium {
        background: #ffffff;
        border: 1px solid var(--border-light);
        border-radius: 1.5rem; /* Melengkung senada dengan gambar hero beranda */
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.03), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
        width: 100%;
        max-width: 1000px;
        overflow: hidden;
    }

    /* SISI KIRI: Informasi (Kini Putih Bersih) */
    .auth-info-side {
        padding: 4rem 3.5rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border-right: 1px solid var(--border-light); /* Pembatas tipis elegan */
        background-color: #ffffff;
    }

    .auth-badge {
        background-color: var(--brand-soft);
        color: var(--brand-color);
        font-size: 12px;
        font-weight: 700;
        padding: 8px 16px;
        border-radius: 50rem;
        border: 1px solid rgba(200, 147, 53, 0.2);
        display: inline-flex;
        align-items: center;
        gap: 6px;
        width: fit-content;
    }

    .feature-point {
        display: flex;
        align-items: flex-start;
        gap: 1.25rem;
        margin-bottom: 1.5rem;
    }

    .feature-icon-box {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background-color: var(--brand-soft);
        color: var(--brand-color);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    /* SISI KANAN: Form (Minimalis) */
    .auth-form-side {
        padding: 4rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        background-color: #ffffff;
    }

    .input-custom {
        min-height: 52px;
        border-radius: 12px;
        border: 1px solid var(--border-light);
        padding: 0.75rem 1.25rem;
        font-size: 14.5px;
        font-weight: 500;
        background-color: #f8fafc;
        color: var(--text-main);
        transition: all 0.2s ease;
    }

    .input-custom::placeholder {
        color: #9ca3af;
    }

    .input-custom:focus {
        background-color: #ffffff;
        border-color: var(--brand-color);
        box-shadow: 0 0 0 4px rgba(200, 147, 53, 0.1);
        outline: none;
    }

    .label-custom {
        font-weight: 700;
        font-size: 13.5px;
        color: var(--text-main);
        margin-bottom: 0.5rem;
    }

    .password-wrapper {
        position: relative;
    }

    .btn-toggle-pass {
        position: absolute;
        right: 16px;
        top: 50%;
        transform: translateY(-50%);
        background: transparent;
        border: none;
        color: var(--text-muted);
        cursor: pointer;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .btn-toggle-pass:hover {
        color: var(--brand-color);
    }

    .form-check-input {
        cursor: pointer;
        border-color: #d1d5db;
    }

    .form-check-input:checked {
        background-color: var(--brand-color);
        border-color: var(--brand-color);
    }

    /* Menyamakan tombol dengan Beranda */
    .btn-brand-pill {
        background-color: var(--brand-color);
        color: white;
        font-weight: 700;
        padding: 14px 24px;
        border-radius: 50rem;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        border: none;
        font-size: 15px;
    }

    .btn-brand-pill:hover {
        background-color: var(--brand-hover);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(200, 147, 53, 0.2);
    }

    /* Responsif */
    @media (max-width: 991px) {
        .auth-form-side, .auth-info-side { padding: 3rem 2.5rem; }
    }
    @media (max-width: 767px) {
        .auth-info-side { display: none; }
        .auth-form-side { padding: 3rem 1.5rem; }
    }
</style>
@endpush

@section('content')
<div class="auth-container">
    <div class="auth-card-premium">
        <div class="row g-0">
            
            <div class="col-md-5 d-none d-md-flex auth-info-side">
                <div class="mb-4">
                    <span class="auth-badge mb-4">
                        <i class="bi bi-shield-check"></i> Akses Pelanggan
                    </span>
                    <h2 class="fw-bolder text-dark mb-3" style="letter-spacing: -0.03em; line-height: 1.2; font-size: 28px;">
                        Lanjutkan Pengalaman<br>Belanja Anda.
                    </h2>
                    <p class="text-muted small mb-5" style="line-height: 1.6;">
                        Masuk untuk menyimpan produk ke keranjang, mengelola alamat pengiriman, dan melacak status pesanan secara real-time.
                    </p>
                </div>

                <div class="features-list">
                    <div class="feature-point">
                        <div class="feature-icon-box"><i class="bi bi-cart3"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-dark" style="font-size: 14px;">Keranjang Tersimpan</h6>
                            <p class="text-muted mb-0" style="font-size: 12.5px; line-height: 1.5;">Produk pilihan Anda tetap aman di keranjang antar perangkat.</p>
                        </div>
                    </div>
                    <div class="feature-point">
                        <div class="feature-icon-box"><i class="bi bi-geo-alt"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-dark" style="font-size: 14px;">Manajemen Alamat Cepat</h6>
                            <p class="text-muted mb-0" style="font-size: 12.5px; line-height: 1.5;">Simpan lokasi pengiriman untuk checkout yang lebih praktis.</p>
                        </div>
                    </div>
                    <div class="feature-point mb-0">
                        <div class="feature-icon-box"><i class="bi bi-box-seam"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-dark" style="font-size: 14px;">Pantau Pesanan Pabrik</h6>
                            <p class="text-muted mb-0" style="font-size: 12.5px; line-height: 1.5;">Lacak langsung status produksi hingga pengiriman pesanan Anda.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-7 auth-form-side">
                
                <div class="mb-5 d-md-none text-center">
                    <div class="brand-logo-box mx-auto mb-3" style="width: 48px; height: 48px; background: var(--brand-color); color: white; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 20px;">ST</div>
                    <h3 class="fw-bolder text-dark m-0" style="letter-spacing: -0.02em;">Masuk Akun</h3>
                    <p class="text-muted mt-2 small">Lanjutkan perjalanan belanja Anda.</p>
                </div>

                <div class="mb-4 d-none d-md-block">
                    <h3 class="fw-bolder text-dark m-0" style="letter-spacing: -0.02em;">Selamat Datang Kembali</h3>
                    <p class="text-muted mt-2 small">Masukkan kredensial akun yang telah didaftarkan.</p>
                </div>

                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show border-0 rounded-3 shadow-sm d-flex align-items-center mb-4" style="background-color: #f0fdf4; color: #166534;" role="alert">
                        <i class="bi bi-check-circle-fill me-3 fs-5"></i>
                        <div class="fw-semibold" style="font-size: 13.5px;">{{ session('success') }}</div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                @if(session('error') || $errors->any())
                    <div class="alert alert-danger alert-dismissible fade show border-0 rounded-3 shadow-sm d-flex align-items-center mb-4" style="background-color: #fef2f2; color: #991b1b;" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-3 fs-5"></i>
                        <div class="fw-semibold" style="font-size: 13.5px;">
                            {{ session('error') ?? $errors->first() }}
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <form action="{{ route('pembeli-web.login.post') }}" method="POST">
                    @csrf

                    <div class="mb-4">
                        <label for="login" class="label-custom">Email atau Nomor WhatsApp</label>
                        <input 
                            type="text" 
                            id="login" 
                            name="login" 
                            class="form-control input-custom" 
                            value="{{ old('login') }}" 
                            placeholder="Contoh: nama@email.com / 08123456789" 
                            autofocus
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label for="password" class="label-custom">Kata Sandi</label>
                        <div class="password-wrapper">
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                class="form-control input-custom" 
                                placeholder="Masukkan kata sandi akun Anda"
                                required
                            >
                            <button type="button" class="btn-toggle-pass" id="btnTogglePassword" aria-label="Tampilkan Sandi">
                                <i class="bi bi-eye fs-5" id="iconEye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4 pb-2">
                        <div class="form-check">
                            <input class="form-check-input shadow-sm" type="checkbox" name="remember" value="1" id="rememberMe">
                            <label class="form-check-label text-muted fw-semibold" for="rememberMe" style="font-size: 13.5px; cursor: pointer;">
                                Ingat Perangkat Ini
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn-brand-pill w-100 shadow-sm">
                        Masuk Ke Akun
                    </button>
                </form>

                <div class="text-center mt-4 pt-3 border-top" style="border-color: var(--border-light) !important;">
                    <span class="text-muted" style="font-size: 13.5px;">Belum memiliki akun pembeli?</span>
                    <a href="{{ route('pembeli-web.register') }}" class="text-decoration-none fw-bolder ms-1" style="color: var(--brand-color); font-size: 13.5px;">
                        Daftar Sekarang
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Fitur interaktif untuk memperlihatkan/menyembunyikan password input
    document.addEventListener("DOMContentLoaded", function() {
        const btnTogglePassword = document.querySelector('#btnTogglePassword');
        const passwordInput = document.querySelector('#password');
        const iconEye = document.querySelector('#iconEye');

        if(btnTogglePassword && passwordInput) {
            btnTogglePassword.addEventListener('click', function (e) {
                e.preventDefault(); // Mencegah form submit jika terklik
                const isPassword = passwordInput.getAttribute('type') === 'password';
                passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
                
                if(isPassword) {
                    iconEye.classList.remove('bi-eye');
                    iconEye.classList.add('bi-eye-slash');
                } else {
                    iconEye.classList.remove('bi-eye-slash');
                    iconEye.classList.add('bi-eye');
                }
            });
        }
    });
</script>
@endpush