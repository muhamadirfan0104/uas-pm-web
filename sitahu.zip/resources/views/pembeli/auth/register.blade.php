@extends('layouts.pembeli')

@section('title', 'Daftar Akun Baru - SiTahu Premium')

@push('styles')
<style>
    /* =========================================
     * PREMIUM & UNIFORM REGISTER UI
     * 100% Selaras dengan Beranda & Login (Clean & Airy)
     * ========================================= */
    .auth-container {
        min-height: calc(100vh - 200px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 3rem 1rem;
    }

    .auth-card-premium {
        background: #ffffff;
        border: 1px solid var(--border-light);
        border-radius: 1.5rem;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.03), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
        width: 100%;
        max-width: 1050px; /* Sedikit lebih lebar dari login karena formnya lebih banyak */
        overflow: hidden;
    }

    /* SISI KIRI: Informasi (Putih Bersih) */
    .auth-info-side {
        padding: 4rem 3.5rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border-right: 1px solid var(--border-light);
        background-color: #ffffff;
    }

    .auth-badge {
        background-color: var(--brand-soft);
        color: var(--brand-color);
        font-size: 12px;
        font-weight: 700;
        padding: 8px 16px;
        border-radius: 50rem;
        border: 1px solid rgba(200, 147, 53, 0.2);
        display: inline-flex;
        align-items: center;
        gap: 6px;
        width: fit-content;
    }

    .feature-point {
        display: flex;
        align-items: flex-start;
        gap: 1.25rem;
        margin-bottom: 1.5rem;
    }

    .feature-icon-box {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background-color: var(--brand-soft);
        color: var(--brand-color);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    /* SISI KANAN: Form (Minimalis) */
    .auth-form-side {
        padding: 3.5rem 4rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        background-color: #ffffff;
    }

    .input-custom {
        min-height: 48px;
        border-radius: 12px;
        border: 1px solid var(--border-light);
        padding: 0.75rem 1.25rem;
        font-size: 14px;
        font-weight: 500;
        background-color: #f8fafc;
        color: var(--text-main);
        transition: all 0.2s ease;
    }

    .input-custom::placeholder {
        color: #9ca3af;
    }

    .input-custom:focus {
        background-color: #ffffff;
        border-color: var(--brand-color);
        box-shadow: 0 0 0 4px rgba(200, 147, 53, 0.1);
        outline: none;
    }

    .label-custom {
        font-weight: 700;
        font-size: 13px;
        color: var(--text-main);
        margin-bottom: 0.5rem;
    }

    .password-wrapper {
        position: relative;
    }

    .btn-toggle-pass {
        position: absolute;
        right: 16px;
        top: 50%;
        transform: translateY(-50%);
        background: transparent;
        border: none;
        color: var(--text-muted);
        cursor: pointer;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .btn-toggle-pass:hover {
        color: var(--brand-color);
    }

    /* Menyamakan tombol dengan Beranda & Login */
    .btn-brand-pill {
        background-color: var(--brand-color);
        color: white;
        font-weight: 700;
        padding: 14px 24px;
        border-radius: 50rem;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        border: none;
        font-size: 15px;
    }

    .btn-brand-pill:hover {
        background-color: var(--brand-hover);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(200, 147, 53, 0.2);
    }

    .error-feedback {
        color: #dc2626;
        font-size: 12px;
        font-weight: 600;
        margin-top: 6px;
    }

    /* Responsif */
    @media (max-width: 991px) {
        .auth-form-side, .auth-info-side { padding: 3rem 2.5rem; }
    }
    @media (max-width: 767px) {
        .auth-info-side { display: none; }
        .auth-form-side { padding: 3rem 1.5rem; }
    }
</style>
@endpush

@section('content')
<div class="auth-container">
    <div class="auth-card-premium">
        <div class="row g-0">
            
            <div class="col-md-5 d-none d-md-flex auth-info-side">
                <div class="mb-4">
                    <span class="auth-badge mb-4">
                        <i class="bi bi-star-fill"></i> Pelanggan Baru
                    </span>
                    <h2 class="fw-bolder text-dark mb-3" style="letter-spacing: -0.03em; line-height: 1.2; font-size: 28px;">
                        Langkah Awal Menikmati<br>Kualitas Terbaik.
                    </h2>
                    <p class="text-muted small mb-5" style="line-height: 1.6;">
                        Bergabunglah bersama ribuan pelanggan kami. Nikmati kemudahan memesan produk olahan kedelai segar langsung dari pabrik ke rumah Anda.
                    </p>
                </div>

                <div class="features-list">
                    <div class="feature-point">
                        <div class="feature-icon-box"><i class="bi bi-lightning-charge"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-dark" style="font-size: 14px;">Pemesanan Praktis</h6>
                            <p class="text-muted mb-0" style="font-size: 12.5px; line-height: 1.5;">Checkout lebih cepat dengan menyimpan alamat pengiriman Anda.</p>
                        </div>
                    </div>
                    <div class="feature-point">
                        <div class="feature-icon-box"><i class="bi bi-clock-history"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-dark" style="font-size: 14px;">Riwayat Transaksi Terpusat</h6>
                            <p class="text-muted mb-0" style="font-size: 12.5px; line-height: 1.5;">Akses dan pantau seluruh pesanan tahu segar Anda di satu tempat.</p>
                        </div>
                    </div>
                    <div class="feature-point mb-0">
                        <div class="feature-icon-box"><i class="bi bi-chat-heart"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-dark" style="font-size: 14px;">Ulasan & Kualitas</h6>
                            <p class="text-muted mb-0" style="font-size: 12.5px; line-height: 1.5;">Bantu kami terus memberikan yang terbaik melalui ulasan Anda setelah pesanan selesai.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-7 auth-form-side">
                
                <div class="mb-4 d-md-none text-center">
                    <div class="mx-auto mb-3" style="width: 48px; height: 48px; background: var(--brand-color); color: white; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 20px;">ST</div>
                    <h3 class="fw-bolder text-dark m-0" style="letter-spacing: -0.02em;">Daftar Akun</h3>
                    <p class="text-muted mt-2 small">Mulai perjalanan belanja Anda bersama kami.</p>
                </div>

                <div class="mb-4 d-none d-md-block">
                    <h3 class="fw-bolder text-dark m-0" style="letter-spacing: -0.02em;">Daftar Akun Baru</h3>
                    <p class="text-muted mt-2 small">Lengkapi data diri Anda di bawah ini untuk mulai berbelanja.</p>
                </div>

                @if($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show border-0 rounded-3 shadow-sm d-flex align-items-center mb-4" style="background-color: #fef2f2; color: #991b1b;" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-3 fs-5"></i>
                        <div class="fw-semibold" style="font-size: 13.5px;">
                            {{ $errors->first() }}
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <form action="{{ route('pembeli-web.register.post') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label for="name" class="label-custom">Nama Lengkap</label>
                        <input 
                            type="text" 
                            id="name" 
                            name="name" 
                            class="form-control input-custom @error('name') is-invalid @enderror" 
                            value="{{ old('name') }}" 
                            placeholder="Masukkan nama lengkap Anda" 
                            autofocus
                        >
                        @error('name') <div class="error-feedback">{{ $message }}</div> @enderror
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label for="email" class="label-custom">Alamat Email</label>
                            <input 
                                type="email" 
                                id="email" 
                                name="email" 
                                class="form-control input-custom @error('email') is-invalid @enderror" 
                                value="{{ old('email') }}" 
                                placeholder="nama@email.com"
                            >
                            @error('email') <div class="error-feedback">{{ $message }}</div> @enderror
                        </div>
                        <div class="col-md-6">
                            <label for="telepon" class="label-custom">Nomor WhatsApp</label>
                            <input 
                                type="text" 
                                id="telepon" 
                                name="telepon" 
                                class="form-control input-custom @error('telepon') is-invalid @enderror" 
                                value="{{ old('telepon') }}" 
                                placeholder="Contoh: 08123456789"
                            >
                            @error('telepon') <div class="error-feedback">{{ $message }}</div> @enderror
                        </div>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label for="password" class="label-custom">Kata Sandi</label>
                            <div class="password-wrapper">
                                <input 
                                    type="password" 
                                    id="password" 
                                    name="password" 
                                    class="form-control input-custom @error('password') is-invalid @enderror" 
                                    placeholder="Minimal 6 karakter"
                                >
                                <button type="button" class="btn-toggle-pass" onclick="togglePass('password', 'iconPass1')" aria-label="Tampilkan Sandi">
                                    <i class="bi bi-eye fs-6" id="iconPass1"></i>
                                </button>
                            </div>
                            @error('password') <div class="error-feedback">{{ $message }}</div> @enderror
                        </div>
                        <div class="col-md-6">
                            <label for="password_confirmation" class="label-custom">Konfirmasi Sandi</label>
                            <div class="password-wrapper">
                                <input 
                                    type="password" 
                                    id="password_confirmation" 
                                    name="password_confirmation" 
                                    class="form-control input-custom" 
                                    placeholder="Ulangi kata sandi"
                                >
                                <button type="button" class="btn-toggle-pass" onclick="togglePass('password_confirmation', 'iconPass2')" aria-label="Tampilkan Sandi">
                                    <i class="bi bi-eye fs-6" id="iconPass2"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn-brand-pill w-100 shadow-sm mt-2">
                        Daftar Akun Sekarang
                    </button>
                </form>

                <div class="text-center mt-4 pt-3 border-top" style="border-color: var(--border-light) !important;">
                    <span class="text-muted" style="font-size: 13.5px;">Sudah memiliki akun?</span>
                    <a href="{{ route('pembeli-web.login') }}" class="text-decoration-none fw-bolder ms-1" style="color: var(--brand-color); font-size: 13.5px;">
                        Masuk Ke Akun
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Fungsi dinamis untuk memperlihatkan/menyembunyikan password di kedua field
    function togglePass(inputId, iconId) {
        const passwordInput = document.getElementById(inputId);
        const iconEye = document.getElementById(iconId);

        if (passwordInput && iconEye) {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
            
            if (isPassword) {
                iconEye.classList.remove('bi-eye');
                iconEye.classList.add('bi-eye-slash');
            } else {
                iconEye.classList.remove('bi-eye-slash');
                iconEye.classList.add('bi-eye');
            }
        }
    }
</script>
@endpush