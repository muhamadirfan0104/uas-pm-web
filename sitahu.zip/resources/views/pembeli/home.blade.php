@extends('layouts.pembeli')

@section('title', 'Beranda Pembeli - SiTahu')

@push('styles')
<style>
    /* =========================================
     * PREMIUM E-COMMERCE UI (Bootstrap 5 + Custom)
     * ========================================= */
    :root {
        --brand-color: #c89335;
        --brand-hover: #b5822b;
        --brand-soft: #fefcf7;
        --text-dark: #1f2937;
        --text-muted: #6b7280;
        --bg-light: #f8fafc;
    }

    /* Utilities */
    .text-brand { color: var(--brand-color) !important; }
    .bg-brand-soft { background-color: var(--brand-soft) !important; }
    
    /* Buttons */
    .btn-brand {
        background-color: var(--brand-color);
        color: white;
        font-weight: 600;
        padding: 0.75rem 1.75rem;
        border-radius: 50rem;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        border: none;
    }
    .btn-brand:hover {
        background-color: var(--brand-hover);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(200, 147, 53, 0.3);
    }

    /* Typography */
    .heading-premium {
        font-weight: 800;
        color: var(--text-dark);
        letter-spacing: -0.03em;
        line-height: 1.2;
    }
    .section-title {
        font-weight: 800;
        color: var(--text-dark);
        letter-spacing: -0.02em;
        position: relative;
        padding-bottom: 0.5rem;
    }
    .text-truncate-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    /* Layouts */
    .scroll-horizontal {
        display: flex;
        flex-wrap: nowrap;
        overflow-x: auto;
        padding-bottom: 1rem;
        gap: 1.25rem;
        scrollbar-width: none; /* Firefox */
    }
    .scroll-horizontal::-webkit-scrollbar { display: none; }

    /* Product Cards with Hover Zoom */
    .product-card {
        border: 1px solid #edf2f7;
        border-radius: 1rem;
        background: #ffffff;
        transition: all 0.3s ease;
        overflow: hidden;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .product-card:hover {
        border-color: #e2e8f0;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
        transform: translateY(-4px);
    }
    .product-img-wrapper {
        position: relative;
        width: 100%;
        padding-top: 100%; /* 1:1 Aspect Ratio */
        overflow: hidden;
        background: #f1f5f9;
    }
    .product-img-wrapper img {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    .product-card:hover .product-img-wrapper img {
        transform: scale(1.08); /* Modern Zoom Effect */
    }
    
    /* Category Icons */
    .cat-box {
        width: 72px; height: 72px;
        border-radius: 1.25rem;
        background: #ffffff;
        display: flex; align-items: center; justify-content: center;
        font-size: 2rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    .cat-item:hover .cat-box {
        background: var(--brand-soft);
        border-color: var(--brand-color);
        transform: translateY(-5px);
        color: var(--brand-color);
    }

    /* Value Proposition (Trust Badges) */
    .value-card {
        background: #ffffff;
        border-radius: 1rem;
        padding: 1.5rem;
        height: 100%;
        border: 1px solid #edf2f7;
        transition: all 0.3s ease;
    }
    .value-card:hover { box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05); }
    .value-icon {
        width: 48px; height: 48px;
        border-radius: 50%;
        background: var(--brand-soft);
        color: var(--brand-color);
        display: flex; align-items: center; justify-content: center;
        font-size: 1.5rem;
        margin-bottom: 1rem;
    }

    /* Mid Banner */
    .premium-banner {
        background: linear-gradient(135deg, #0f172a 0%, #334155 100%);
        border-radius: 1.5rem;
        position: relative;
        overflow: hidden;
    }
    .premium-banner::after {
        content: '';
        position: absolute;
        top: -50%; right: -10%;
        width: 300px; height: 300px;
        background: radial-gradient(circle, rgba(200,147,53,0.2) 0%, rgba(0,0,0,0) 70%);
        border-radius: 50%;
    }
</style>
@endpush

@section('content')
@php
    // Fallback copywriting yang elegan
    $namaToko = $pengaturan->nama ?: 'SiTahu Premium';
    $tentangToko = $pengaturan->tentang ?: 'Menghadirkan kebaikan kedelai alami dalam setiap gigitan. Diproduksi secara higienis setiap hari untuk nutrisi keluarga Anda.';
    
    $teleponToko = $pengaturan->telepon ?: '';
    $nomorWa = preg_replace('/[^0-9]/', '', $teleponToko);
    if ($nomorWa && str_starts_with($nomorWa, '0')) { $nomorWa = '62' . substr($nomorWa, 1); }
    
    $linkWaUmum = $nomorWa ? 'https://wa.me/' . $nomorWa . '?text=' . urlencode('Halo ' . $namaToko . ', saya butuh bantuan untuk pemesanan.') : route('pembeli-web.coming-soon');
    $linkWaB2B = $nomorWa ? 'https://wa.me/' . $nomorWa . '?text=' . urlencode('Halo, saya tertarik untuk menjadi mitra/pesan dalam partai besar.') : route('pembeli-web.coming-soon');
@endphp

<div class="container py-4 py-lg-5">

    <div class="row align-items-center mb-5 pb-4 g-4 flex-column-reverse flex-lg-row">
        <div class="col-lg-6 text-center text-lg-start pe-lg-5">
            <span class="badge bg-brand-soft text-brand mb-3 px-3 py-2 rounded-pill fw-bold" style="font-size: 12px; border: 1px solid var(--brand-color);">
                馃専 100% Kedelai Pilihan Asli
            </span>
            <h1 class="heading-premium mb-4 display-5">Kualitas Tahu Segar <br> Langsung dari Pabriknya.</h1>
            <p class="text-muted fs-5 mb-4" style="line-height: 1.6;">{{ $tentangToko }}</p>
            <div class="d-flex flex-column flex-sm-row gap-3 justify-content-center justify-content-lg-start">
                <a href="{{ route('pembeli-web.produk') }}" class="btn btn-brand fs-6">Eksplor Produk</a>
                <a href="{{ $linkWaUmum }}" target="_blank" class="btn btn-light rounded-pill px-4 py-2 fw-semibold text-dark border shadow-sm">
                    <i class="bi bi-whatsapp text-success me-2"></i> Hubungi Kami
                </a>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="position-relative text-center">
                @if($pengaturan->logo_url)
                    <img src="{{ asset('storage/' . $pengaturan->logo_url) }}" alt="{{ $namaToko }}" class="img-fluid rounded-circle shadow-lg" style="width: 350px; height: 350px; object-fit: cover; border: 8px solid white;">
                @else
                    <div class="rounded-circle shadow-lg mx-auto d-flex align-items-center justify-content-center bg-white text-brand" style="width: 350px; height: 350px; border: 8px solid white; font-size: 80px; font-weight: 900;">
                        ST
                    </div>
                @endif
            </div>
        </div>
    </div>

    <div class="row g-3 g-lg-4 mb-5 pb-3">
        <div class="col-6 col-md-3">
            <div class="value-card">
                <div class="value-icon">馃憠</div>
                <h6 class="fw-bold mb-2">Kedelai Premium</h6>
                <p class="text-muted small mb-0 d-none d-md-block">Bahan baku pilihan dengan standar kualitas tinggi.</p>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="value-card">
                <div class="value-icon">馃敟</div>
                <h6 class="fw-bold mb-2">Produksi Harian</h6>
                <p class="text-muted small mb-0 d-none d-md-block">Selalu segar setiap hari, langsung dari pabrik kami.</p>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="value-card">
                <div class="value-icon">馃専</div>
                <h6 class="fw-bold mb-2">Bebas Pengawet</h6>
                <p class="text-muted small mb-0 d-none d-md-block">Sehat dan aman dikonsumsi oleh seluruh keluarga.</p>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="value-card">
                <div class="value-icon">馃洠锔</div>
                <h6 class="fw-bold mb-2">Pengiriman Aman</h6>
                <p class="text-muted small mb-0 d-none d-md-block">Dikemas rapi untuk menjaga kualitas tiba di tujuan.</p>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between align-items-end mb-4">
        <h3 class="section-title fs-4 m-0">Kategori Pilihan</h3>
    </div>
    <div class="scroll-horizontal mb-5 pb-3">
        @php
            $kategori = [
                ['icon' => '馃グ', 'name' => 'Semua Produk'],
                ['icon' => '馃尦', 'name' => 'Tahu Putih'],
                ['icon' => '馃嵆', 'name' => 'Tahu Kuning'],
                ['icon' => '馃嵉', 'name' => 'Tahu Goreng'],
                ['icon' => '馃寪', 'name' => 'Paket Hemat'],
            ];
        @endphp
        @foreach($kategori as $kat)
            <a href="{{ route('pembeli-web.produk') }}" class="text-decoration-none text-dark cat-item d-flex flex-column align-items-center gap-2" style="min-width: 90px;">
                <div class="cat-box">{{ $kat['icon'] }}</div>
                <span class="fw-semibold text-center" style="font-size: 13.5px;">{{ $kat['name'] }}</span>
            </a>
        @endforeach
    </div>

    @if($produkTerlaris->count())
    <div class="d-flex justify-content-between align-items-end mb-4">
        <div>
            <h3 class="section-title fs-4 m-0">Favorit Pelanggan</h3>
            <p class="text-muted small mt-1 mb-0">Pilihan terbaik yang paling banyak dipesan.</p>
        </div>
        <a href="{{ route('pembeli-web.produk') }}" class="text-brand text-decoration-none fw-bold" style="font-size: 14px;">Lihat Semua</a>
    </div>
    
    <div class="scroll-horizontal mb-5 pb-4">
        @foreach($produkTerlaris as $produk)
            <a href="{{ route('pembeli-web.produk') }}" class="product-card text-decoration-none flex-shrink-0" style="width: 220px;">
                <div class="position-absolute top-0 start-0 m-3 z-3">
                    <span class="badge bg-danger text-white fw-bold px-2 py-1 shadow-sm">馃敟 Terlaris</span>
                </div>
                <div class="product-img-wrapper">
                    @if($produk->gambarUtama && $produk->gambarUtama->url_gambar)
                        <img src="{{ asset('storage/' . $produk->gambarUtama->url_gambar) }}" alt="{{ $produk->nama }}">
                    @else
                        <div class="d-flex align-items-center justify-content-center h-100 w-100 text-muted fw-semibold" style="font-size: 12px; position: absolute;">NO IMAGE</div>
                    @endif
                </div>
                <div class="p-3 d-flex flex-column flex-grow-1">
                    <h6 class="text-dark fw-semibold text-truncate-2 mb-2" style="font-size: 15px;">{{ $produk->nama }}</h6>
                    <div class="fw-bolder text-dark mb-3" style="font-size: 18px;">Rp {{ number_format($produk->harga, 0, ',', '.') }}</div>
                    <div class="mt-auto d-flex justify-content-between align-items-center text-muted" style="font-size: 12px;">
                        <span>⭐ 4.9 | Sisa {{ $produk->stok }}</span>
                        <div class="bg-brand-soft text-brand rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                            <i class="bi bi-plus-lg"></i>
                        </div>
                    </div>
                </div>
            </a>
        @endforeach
    </div>
    @endif

    <div class="premium-banner p-4 p-md-5 mb-5 shadow-lg">
        <div class="row align-items-center position-relative z-1">
            <div class="col-md-8 text-center text-md-start mb-4 mb-md-0">
                <span class="badge bg-white text-dark mb-3 px-3 py-2 rounded-pill fw-bold" style="font-size: 12px;">PENAWARAN MITRA</span>
                <h3 class="fw-bolder text-white mb-2 fs-3">Kebutuhan Bisnis & Hajatan?</h3>
                <p class="text-light opacity-75 mb-0" style="font-size: 16px; max-width: 500px;">Kami melayani pesanan partai besar dengan harga khusus pabrik untuk katering, restoran, dan acara keluarga.</p>
            </div>
            <div class="col-md-4 text-center text-md-end">
                <a href="{{ $linkWaB2B }}" target="_blank" class="btn btn-light rounded-pill px-4 py-3 fw-bold text-dark shadow">
                    Tanya Harga Grosir <i class="bi bi-arrow-up-right ms-1"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between align-items-end mb-4">
        <div>
            <h3 class="section-title fs-4 m-0">Produk Tersedia</h3>
            <p class="text-muted small mt-1 mb-0">Eksplorasi pilihan tahu segar kami hari ini.</p>
        </div>
    </div>

    @if($produkTerbaru->count())
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-3 g-md-4 mb-5">
            @foreach($produkTerbaru as $produk)
                <div class="col">
                    <a href="{{ route('pembeli-web.produk') }}" class="product-card text-decoration-none">
                        <div class="product-img-wrapper">
                            @if($produk->gambarUtama && $produk->gambarUtama->url_gambar)
                                <img src="{{ asset('storage/' . $produk->gambarUtama->url_gambar) }}" alt="{{ $produk->nama }}">
                            @else
                                <div class="d-flex align-items-center justify-content-center h-100 w-100 text-muted fw-semibold" style="font-size: 12px; position: absolute;">PRODUK TAHU</div>
                            @endif
                        </div>
                        <div class="p-3 d-flex flex-column flex-grow-1">
                            <h6 class="text-dark fw-semibold text-truncate-2 mb-2" style="font-size: 14px;">{{ $produk->nama }}</h6>
                            <div class="fw-bolder text-dark mb-3" style="font-size: 16px;">Rp {{ number_format($produk->harga, 0, ',', '.') }}</div>
                            <div class="mt-auto border-top pt-3 d-flex justify-content-between align-items-center text-muted" style="font-size: 12px;">
                                <span class="text-truncate me-2"><i class="bi bi-shop"></i> {{ $namaToko }}</span>
                                <span class="badge bg-light text-dark border">Stok {{ $produk->stok }}</span>
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>
    @else
        <div class="text-center p-5 border rounded-4 bg-white mb-5 shadow-sm">
            <div class="fs-1 mb-3">馃槫</div>
            <h5 class="fw-bold text-dark">Belum Ada Produk</h5>
            <p class="text-muted m-0">Kami sedang menyiapkan produk tahu segar terbaik untuk Anda.</p>
        </div>
    @endif

    <div class="mb-5 pb-5">
        <h3 class="section-title fs-4 text-center mb-4">Apa Kata Pelanggan Kami?</h3>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="value-card text-center">
                    <div class="text-warning mb-2 fs-5">⭐⭐⭐⭐⭐</div>
                    <p class="text-dark fw-medium small mb-3">"Tahunya beneran fresh, pas digoreng teksturnya krispi di luar tapi lembut di dalam. Langganan buat makan keluarga!"</p>
                    <span class="text-muted fw-bold" style="font-size: 12px;">- Ibu Siti, Pelanggan Setia</span>
                </div>
            </div>
            <div class="col-md-4 d-none d-md-block">
                <div class="value-card text-center">
                    <div class="text-warning mb-2 fs-5">⭐⭐⭐⭐⭐</div>
                    <p class="text-dark fw-medium small mb-3">"Pesanan untuk hajatan keluarga sampai tepat waktu. Packaging rapi dan kualitas tahunya mantap banget. Terima kasih!"</p>
                    <span class="text-muted fw-bold" style="font-size: 12px;">- Bpk. Budi, Pemilik Katering</span>
                </div>
            </div>
            <div class="col-md-4 d-none d-md-block">
                <div class="value-card text-center">
                    <div class="text-warning mb-2 fs-5">⭐⭐⭐⭐⭐</div>
                    <p class="text-dark fw-medium small mb-3">"Udah nyoba beli di pasar, tapi balik lagi pesen di sini. Bebas pengawetnya itu loh yang bikin tenang ngasih makan anak-anak."</p>
                    <span class="text-muted fw-bold" style="font-size: 12px;">- Mbak Rina, Ibu Rumah Tangga</span>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection