@extends('layouts.admin')
@section('title', 'Pengambilan & Pengantaran - SiTahu')

@section('content')
<style>
    /* Styling Standar E-Commerce Logistik */
    .sc-box { border: 1px solid #e5e7eb; border-radius: 0.75rem; background: #fff; margin-bottom: 1.5rem; overflow: hidden; box-shadow: 0 1px 2px rgba(0,0,0,0.02); }
    .sc-header { padding: 1rem 1.25rem; font-weight: 700; font-size: 1rem; border-bottom: 1px solid #f3f4f6; color: #111827; display: flex; align-items: center; gap: 0.5rem; }
    
    /* Peta Placeholder */
    .map-placeholder { height: 180px; background-color: #e5e7eb; background-image: radial-gradient(#d1d5db 1px, transparent 0); background-size: 20px 20px; display: flex; align-items: center; justify-content: center; position: relative; border-radius: 0 0 0.75rem 0.75rem; }
    .map-pin { font-size: 2.5rem; color: #ef4444; filter: drop-shadow(0 4px 4px rgba(0,0,0,0.2)); }
    
    /* Tabel Enterprise */
    .table-enterprise th { border-bottom: 2px solid #e5e7eb; color: #6b7280; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; padding: 1rem 1.25rem; font-weight: 600; background: #fafafa; }
    .table-enterprise td { vertical-align: middle; padding: 1rem 1.25rem; border-bottom: 1px solid #f3f4f6; color: #111827; }
    .table-enterprise tbody tr:hover { background-color: #f9fafb; }

    /* Form Inline Status */
    .form-select-inline { background-color: #f9fafb; border: 1px solid #e5e7eb; font-size: 0.85rem; font-weight: 500; color: #374151; box-shadow: none; transition: all 0.2s; }
    .form-select-inline:focus { background-color: #ffffff; border-color: var(--brand-color, #dfba68); box-shadow: 0 0 0 3px rgba(223, 186, 104, 0.15); }
</style>

<div class="d-flex flex-column flex-md-row align-items-md-end justify-content-between gap-3 mb-4">
    <div>
        <h1 class="h4 fw-bold text-dark mb-1">Pengambilan & Pengantaran</h1>
        <p class="text-muted small mb-0">Kelola status pesanan *Ambil di Toko* dan *Kurir Toko*.</p>
    </div>
    <div>
        <a class="btn shadow-sm fw-bold px-4 text-white d-flex align-items-center gap-2" href="{{ route('admin.pengaturan.edit') }}" style="background: var(--brand-color, #dfba68);">
            <i class="bi bi-gear"></i> Atur Logistik Toko
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-12 col-xl-6">
        <div class="sc-box h-100 mb-0">
            <div class="sc-header bg-light">
                <i class="bi bi-sliders text-muted"></i> Konfigurasi Logistik Saat Ini
            </div>
            <div class="p-4 d-flex flex-column gap-3 justify-content-center h-100">
                <div class="d-flex justify-content-between align-items-center border-bottom pb-3">
                    <span class="text-muted small fw-bold text-uppercase">Alamat Titik Toko</span>
                    <span class="text-dark fw-medium text-end" style="max-width: 60%; font-size: 0.9rem;">
                        {{ $pengaturan->alamat ?? 'Belum diatur' }}
                    </span>
                </div>
                <div class="d-flex justify-content-between align-items-center border-bottom pb-3">
                    <span class="text-muted small fw-bold text-uppercase">Biaya Min. Pengiriman</span>
                    <span class="text-dark fw-bold fs-5">{{ $rupiah($pengaturan->biaya_minimum_pengiriman) }}</span>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-muted small fw-bold text-uppercase">Radius Maksimal Pengantaran</span>
                    <span class="badge bg-info-subtle text-info-emphasis rounded-pill px-3 py-2 fs-6">
                        {{ $pengaturan->radius_maksimal_km ?? '0' }} KM
                    </span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-12 col-xl-6">
        <div class="sc-box h-100 mb-0 d-flex flex-column">
            <div class="sc-header bg-light">
                <i class="bi bi-geo-alt text-danger"></i> Area Jangkauan Peta
            </div>
            <div class="map-placeholder flex-grow-1">
                <i class="bi bi-geo-alt-fill map-pin"></i>
                <div class="position-absolute bottom-0 start-0 w-100 p-2 bg-white bg-opacity-75 text-center small fw-medium text-dark">
                    Titik Kordinat SiTahu
                </div>
            </div>
        </div>
    </div>
</div>

<div class="sc-box border-light shadow-sm rounded-4 overflow-hidden mb-4">
    
    <div class="bg-white border-bottom p-3 p-md-4">
        <form id="page-filter" method="GET">
            <div class="row g-3 align-items-center">
                <div class="col-12 col-md-5 col-lg-4">
                    <select class="form-select bg-light border-light fw-medium" name="metode" style="border-radius: 0.75rem; min-height: 46px;">
                        <option value="">Semua Metode Logistik</option>
                        <option value="ambil_toko" @selected(request('metode')==='ambil_toko')>Ambil di Toko</option>
                        <option value="kurir_toko" @selected(request('metode')==='kurir_toko')>Kurir Toko (Diantar)</option>
                    </select>
                </div>
                <div class="col-12 col-md-4 col-lg-3">
                    <select class="form-select bg-light border-light fw-medium" name="status" style="border-radius: 0.75rem; min-height: 46px;">
                        <option value="">Semua Status Pengiriman</option>
                        @foreach(['siap_diambil','dalam_pengantaran','selesai'] as $s)
                            <option value="{{ $s }}" @selected(request('status')===$s)>{{ $statusLabel($s) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-12 col-md-3 col-lg-2">
                    <button class="btn btn-dark w-100 fw-medium" type="submit" style="border-radius: 0.75rem; min-height: 46px;">Saring Data</button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-responsive bg-white">
        <table class="table table-enterprise table-borderless mb-0" style="min-width: 900px;">
            <thead>
                <tr>
                    <th class="ps-4">Pesanan</th>
                    <th>Detail Pengiriman / Alamat</th>
                    <th>Biaya Logistik</th>
                    <th>Status Saat Ini</th>
                    <th class="pe-4 text-end">Update Status Logistik</th>
                </tr>
            </thead>
            <tbody>
            @forelse($pengiriman as $ship)
                <tr>
                    <td class="ps-4">
                        <strong class="d-block text-dark mb-1" style="font-size: 0.95rem;">
                            {{ $ship->pesanan?->nomor_invoice ?? 'INV-UNKNOWN' }}
                        </strong>
                        <div class="text-muted small">
                            Pembeli: <span class="fw-medium text-dark">{{ $ship->pesanan?->user?->name ?? 'Anonim' }}</span>
                        </div>
                    </td>
                    <td>
                        <div class="d-flex align-items-start gap-2">
                            <div class="mt-1">
                                @if($ship->metode === 'ambil_toko')
                                    <i class="bi bi-shop text-warning fs-5"></i>
                                @else
                                    <i class="bi bi-truck text-primary fs-5"></i>
                                @endif
                            </div>
                            <div>
                                <span class="badge bg-light text-secondary border rounded-pill mb-1 fw-medium" style="font-size: 0.7rem;">
                                    {{ $statusLabel($ship->metode) }}
                                </span>
                                <div class="text-dark small lh-sm" style="max-width: 250px;">
                                    {{ $ship->alamat_tujuan ?: $ship->alamat_toko }}
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        @if($ship->biaya > 0)
                            <strong class="text-dark">{{ $rupiah($ship->biaya) }}</strong>
                        @else
                            <span class="badge bg-success-subtle text-success-emphasis rounded-pill">Gratis</span>
                        @endif
                    </td>
                    <td>
                        <span class="badge rounded-pill fw-medium px-2 py-1 {{ str_replace('text-bg-', 'bg-', $statusClass($ship->status_pengiriman)) }}-subtle text-{{ str_replace('text-bg-', '', $statusClass($ship->status_pengiriman)) }}-emphasis" style="font-size: 0.75rem;">
                            {{ $statusLabel($ship->status_pengiriman) }}
                        </span>
                    </td>
                    <td class="pe-4">
                        <form method="POST" action="{{ route('admin.pengiriman.status', $ship) }}" class="d-flex justify-content-end align-items-center gap-2 m-0">
                            @csrf @method('PATCH')
                            <select class="form-select form-select-sm form-select-inline rounded-3" name="status_pengiriman" style="width: 160px; height: 34px;">
                                @foreach(['siap_diambil','dalam_pengantaran','selesai'] as $s)
                                    <option value="{{ $s }}" @selected($ship->status_pengiriman === $s)>
                                        Ubah ke: {{ $statusLabel($s) }}
                                    </option>
                                @endforeach
                            </select>
                            <button class="btn btn-sm btn-dark rounded-3 px-3 fw-medium d-flex align-items-center" type="submit" style="height: 34px;">
                                Simpan
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center py-5">
                        <i class="bi bi-truck-flatbed fs-1 text-muted mb-3 d-block"></i>
                        <strong class="text-dark d-block mb-1">Belum ada data pengiriman aktif.</strong>
                        <span class="text-muted small">Pesanan dengan metode ambil/kurir akan muncul di sini.</span>
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
    
    @if($pengiriman->hasPages())
        <div class="bg-light border-top p-3">
            {{ $pengiriman->links() }}
        </div>
    @endif
</div>
@endsection