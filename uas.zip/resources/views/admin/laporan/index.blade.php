@extends('layouts.admin')
@section('title', 'Laporan - SiTahu')

@section('content')
<style>
    /* Elemen Standar Form & Box E-Commerce */
    .sc-box { border: 1px solid #e5e7eb; border-radius: 0.75rem; background: #fff; margin-bottom: 1.5rem; overflow: hidden; box-shadow: 0 1px 2px rgba(0,0,0,0.02); }
    .sc-header { padding: 1.25rem 1.5rem; font-weight: 700; font-size: 1rem; border-bottom: 1px solid #f3f4f6; color: #111827; display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; }
    
    /* Styling Metrik Ringkasan */
    .metric-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 0.75rem; padding: 1.5rem; display: flex; flex-direction: column; justify-content: center; position: relative; overflow: hidden; transition: all 0.2s; }
    .metric-card:hover { border-color: var(--brand-color, #dfba68); box-shadow: 0 4px 12px rgba(223, 186, 104, 0.15); transform: translateY(-2px); }
    .metric-label { font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280; margin-bottom: 0.5rem; }
    .metric-value { font-size: 1.85rem; font-weight: 800; letter-spacing: -0.03em; color: #111827; line-height: 1.1; }
    .metric-icon { position: absolute; right: -10px; bottom: -15px; font-size: 5rem; opacity: 0.04; color: #111827; }

    /* Form Filter Horizontal */
    .form-label-modern { font-size: 0.8rem; font-weight: 700; color: #4b5563; margin-bottom: 0.4rem; }
    .form-control-modern, .form-select-modern { background-color: #f9fafb; border: 1px solid #d1d5db; border-radius: 0.5rem; padding: 0.5rem 0.75rem; font-size: 0.85rem; transition: all 0.2s; }
    .form-control-modern:focus, .form-select-modern:focus { background-color: #ffffff; border-color: var(--brand-color, #dfba68); box-shadow: 0 0 0 3px rgba(223, 186, 104, 0.15); outline: none; }

    /* Tabel Enterprise */
    .table-enterprise th { border-bottom: 2px solid #e5e7eb; color: #6b7280; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; padding: 1rem 1.5rem; font-weight: 600; background: #fafafa; }
    .table-enterprise td { vertical-align: middle; padding: 1rem 1.5rem; border-bottom: 1px solid #f3f4f6; color: #111827; font-size: 0.9rem; }
    .table-enterprise tbody tr:hover { background-color: #f9fafb; }
    
    /* List Produk Terlaris */
    .list-row { transition: background-color 0.15s ease; border-bottom: 1px solid #f3f4f6; padding: 1rem 1.5rem; }
    .list-row:last-child { border-bottom: none; }
    .list-row:hover { background-color: #f9fafb; }
    .thumb-box { width: 40px; height: 40px; border-radius: 0.5rem; background-color: #f3f4f6; border: 1px solid #e5e7eb; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 700; color: #9ca3af; flex-shrink: 0; }
</style>

<div class="d-flex flex-column flex-md-row align-items-md-end justify-content-between gap-3 mb-4">
    <div>
        <h1 class="h4 fw-bold text-dark mb-1">Laporan & Analitik</h1>
        <p class="text-muted small mb-0">Pantau pergerakan penjualan, pesanan, dan tren produk terlaris.</p>
    </div>
    <div>
        <a class="btn shadow-sm fw-bold px-4 text-white d-flex align-items-center gap-2" href="{{ route('admin.laporan.export.csv', request()->query()) }}" style="background: var(--brand-color, #dfba68);">
            <i class="bi bi-file-earmark-spreadsheet"></i> Export ke CSV
        </a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card h-100">
            <div class="metric-label">Total Penjualan</div>
            <div class="metric-value">{{ $rupiah($ringkasan['total_penjualan']) }}</div>
            <i class="bi bi-wallet2 metric-icon"></i>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card h-100">
            <div class="metric-label">Total Pesanan</div>
            <div class="metric-value">{{ $ringkasan['total_pesanan'] }} <span class="fs-6 fw-normal text-muted">Trx</span></div>
            <i class="bi bi-cart3 metric-icon"></i>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card h-100" style="border-left: 4px solid #10b981;">
            <div class="metric-label text-success">Pesanan Selesai</div>
            <div class="metric-value">{{ $ringkasan['pesanan_selesai'] }}</div>
            <i class="bi bi-check-circle metric-icon"></i>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card h-100" style="border-left: 4px solid #ef4444;">
            <div class="metric-label text-danger">Dibatalkan</div>
            <div class="metric-value">{{ $ringkasan['pesanan_dibatalkan'] }}</div>
            <i class="bi bi-x-circle metric-icon"></i>
        </div>
    </div>
</div>

<div class="sc-box mb-4">
    <div class="sc-header bg-light py-3">
        <span><i class="bi bi-funnel text-muted me-2"></i> Parameter Laporan</span>
    </div>
    <div class="p-3 p-md-4">
        <form id="page-filter" method="GET" class="row g-3 align-items-end">
            <div class="col-12 col-md-3">
                <label class="form-label-modern">Jenis Laporan</label>
                <select class="form-select form-select-modern fw-medium" name="jenis">
                    <option value="penjualan" @selected($jenis==='penjualan')>Penjualan Keseluruhan</option>
                    <option value="pesanan" @selected($jenis==='pesanan')>Data Pesanan</option>
                    <option value="produk" @selected($jenis==='produk')>Produk Terlaris</option>
                </select>
            </div>
            <div class="col-12 col-sm-6 col-md-2">
                <label class="form-label-modern">Tanggal Mulai</label>
                <input class="form-control form-control-modern" type="date" name="tanggal_mulai" value="{{ $tanggalMulai->format('Y-m-d') }}">
            </div>
            <div class="col-12 col-sm-6 col-md-2">
                <label class="form-label-modern">Tanggal Selesai</label>
                <input class="form-control form-control-modern" type="date" name="tanggal_selesai" value="{{ $tanggalSelesai->format('Y-m-d') }}">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label-modern">Status Pesanan</label>
                <select class="form-select form-select-modern fw-medium" name="status">
                    <option value="">Semua Status</option>
                    @foreach(['menunggu_pembayaran','dibayar','diproses','siap_diambil','dalam_pengantaran','selesai','dibatalkan'] as $s)
                        <option value="{{ $s }}" @selected(request('status')===$s)>{{ $statusLabel($s) }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-12 col-md-2 d-flex gap-2">
                <button class="btn btn-dark w-100 fw-medium" type="submit" style="padding: 0.5rem; font-size: 0.9rem; border-radius: 0.5rem;">Saring</button>
                <a class="btn btn-light border w-100 fw-medium" href="{{ route('admin.laporan.index') }}" style="padding: 0.5rem; font-size: 0.9rem; border-radius: 0.5rem;">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="row g-4">
    <div class="col-12 col-xl-8">
        <div class="sc-box h-100 mb-0 d-flex flex-column">
            <div class="sc-header">
                <span>Rincian Transaksi</span>
                <span class="badge bg-light text-secondary border fw-normal">Berdasarkan Filter</span>
            </div>
            <div class="table-responsive flex-grow-1">
                <table class="table table-enterprise table-borderless mb-0 w-100">
                    <thead>
                        <tr>
                            <th>No. Invoice</th>
                            <th>Info Pembeli</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th class="text-end">Total Bayar</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pesanan as $order)
                        <tr>
                            <td>
                                <strong class="text-dark">{{ $order->nomor_invoice }}</strong>
                            </td>
                            <td>
                                <div class="fw-medium text-dark">{{ $order->user?->name ?? 'User Terhapus' }}</div>
                            </td>
                            <td class="text-muted small">
                                {{ optional($order->tanggal_pesanan)->format('d M Y, H:i') }}
                            </td>
                            <td>
                                <span class="badge rounded-pill fw-medium px-2 py-1 {{ str_replace('text-bg-', 'bg-', $statusClass($order->status)) }}-subtle text-{{ str_replace('text-bg-', '', $statusClass($order->status)) }}-emphasis" style="font-size: 0.75rem;">
                                    {{ $statusLabel($order->status) }}
                                </span>
                            </td>
                            <td class="text-end fw-bold text-dark">
                                {{ $rupiah($order->total_bayar) }}
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <i class="bi bi-inbox fs-2 text-muted mb-2 d-block"></i>
                                <strong class="text-dark">Tidak ada data transaksi.</strong>
                                <div class="text-muted small mt-1">Coba ubah rentang tanggal atau status filter Anda.</div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if($pesanan->hasPages())
                <div class="p-3 border-top bg-light">
                    {{ $pesanan->links() }}
                </div>
            @endif
        </div>
    </div>

    <div class="col-12 col-xl-4">
        <div class="sc-box h-100 mb-0 d-flex flex-column">
            <div class="sc-header">
                <span>Peringkat Produk</span>
            </div>
            <div class="p-0 flex-grow-1">
                @forelse($produkTerlaris as $produk)
                    <div class="list-row d-flex align-items-center gap-3">
                        <div class="text-muted fw-bold" style="width: 20px;">#{{ $loop->iteration }}</div>
                        <div class="thumb-box"><i class="bi bi-box-seam"></i></div>
                        <div class="flex-grow-1 min-w-0">
                            <strong class="d-block text-dark text-truncate mb-1" style="font-size: 0.9rem;">{{ $produk->nama }}</strong>
                            <div class="text-muted fw-bold" style="font-size: 0.8rem; color: var(--brand-color) !important;">{{ $rupiah($produk->harga) }}</div>
                        </div>
                        <div class="text-end flex-shrink-0">
                            <strong class="d-block text-dark" style="font-size: 1rem;">{{ (int)($produk->total_terjual ?? 0) }}</strong>
                            <span class="text-muted" style="font-size: 0.7rem;">Unit Terjual</span>
                        </div>
                    </div>
                @empty
                    <div class="p-5 text-center">
                        <i class="bi bi-bar-chart fs-2 text-muted mb-2 d-block"></i>
                        <strong class="text-dark">Belum ada peringkat</strong>
                        <div class="text-muted small mt-1">Produk terlaris akan muncul setelah ada pesanan berhasil.</div>
                    </div>
                @endforelse
            </div>
        </div>
    </div>
</div>

@endsection