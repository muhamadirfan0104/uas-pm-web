@extends('layouts.admin')
@section('title', 'Produk Tahu - SiTahu')

@section('content')
<div class="d-flex flex-column flex-md-row align-items-md-end justify-content-between gap-3 mb-4">
    <div>
        <h1 class="h4 fw-bold text-dark mb-1">Daftar Produk</h1>
        <p class="text-muted small mb-0">Kelola katalog produk, harga, dan ketersediaan stok.</p>
    </div>
    <div>
        <button class="btn shadow-sm fw-bold px-4" type="button" data-bs-toggle="modal" data-bs-target="#modalProdukCreate" style="background: var(--brand-color, #dfba68); color: #fff;">
            <i class="bi bi-plus-lg me-1"></i> Tambah Produk
        </button>
    </div>
</div>

<div class="card border border-light shadow-sm rounded-4 overflow-hidden mb-4">
    <div class="bg-white border-bottom p-3">
        <form id="page-filter" method="GET">
            <div class="row g-2 align-items-center">
                <div class="col-12 col-lg">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-search text-muted"></i></span>
                        <input class="form-control border-start-0 bg-light" name="q" value="{{ request('q') }}" placeholder="Cari nama produk...">
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-3">
                    <select class="form-select bg-light" name="status">
                        <option value="">Semua Status</option>
                        <option value="aktif" @selected(request('status')==='aktif')>Aktif</option>
                        <option value="nonaktif" @selected(request('status')==='nonaktif')>Sembunyi</option>
                        <option value="habis" @selected(request('status')==='habis')>Stok Habis</option>
                    </select>
                </div>
                <div class="col-12 col-md-4 col-lg-3">
                    <select class="form-select bg-light" name="sort">
                        <option value="">Terbaru</option>
                        <option value="harga_terendah" @selected(request('sort')==='harga_terendah')>Harga Terendah</option>
                        <option value="harga_tertinggi" @selected(request('sort')==='harga_tertinggi')>Harga Tertinggi</option>
                        <option value="stok_terendah" @selected(request('sort')==='stok_terendah')>Stok Terendah</option>
                    </select>
                </div>
                <div class="col-12 col-md-auto">
                    <button class="btn btn-dark w-100" type="submit">Filter</button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-borderless table-hover align-middle mb-0">
            <thead class="border-bottom text-muted" style="font-size: 0.8rem; text-transform: uppercase;">
                <tr>
                    <th class="ps-4 py-3">Info Produk</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th class="pe-4 text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($produk as $item)
                <tr class="border-bottom">
                    <td class="ps-4 py-3">
                        <div class="d-flex align-items-center gap-3">
                            @if($item->gambarUtama)
                                <img src="{{ asset('storage/'.$item->gambarUtama->url_gambar) }}" class="rounded-3 border object-fit-cover bg-light" style="width: 48px; height: 48px;" alt="{{ $item->nama }}">
                            @else
                                <div class="rounded-3 border bg-light d-flex align-items-center justify-content-center text-muted fw-bold" style="width: 48px; height: 48px;">PR</div>
                            @endif
                            <div>
                                <strong class="d-block text-dark mb-1" style="font-size: 0.95rem;">{{ $item->nama }}</strong>
                                <span class="text-muted small">Isi {{ $item->isi_per_satuan ?? '-' }} pcs • {{ $item->berat ?? '-' }} gr/{{ $item->satuan }}</span>
                            </div>
                        </div>
                    </td>
                    <td><strong class="text-dark">{{ $rupiah($item->harga) }}</strong></td>
                    <td>
                        <span class="badge rounded-pill px-2 py-1 {{ $item->stok <= 0 ? 'bg-danger-subtle text-danger-emphasis' : ($item->stok <= 20 ? 'bg-warning-subtle text-warning-emphasis' : 'bg-success-subtle text-success-emphasis') }}">
                            {{ $item->stok }}
                        </span>
                    </td>
                    <td>
                        <span class="badge rounded-pill px-2 py-1 {{ $item->aktif ? 'bg-info-subtle text-info-emphasis' : 'bg-secondary-subtle text-secondary-emphasis' }}">
                            {{ $item->aktif ? 'Aktif' : 'Disembunyikan' }}
                        </span>
                    </td>
                    <td class="pe-4 text-end">
                        <div class="d-flex justify-content-end gap-1">
                            <button class="btn btn-sm btn-light border" type="button" data-bs-toggle="modal" data-bs-target="#modalProdukEdit{{ $item->id }}"><i class="bi bi-pencil"></i></button>
                            <form method="POST" action="{{ route('admin.produk.toggle',$item) }}" class="d-inline">
                                @csrf @method('PATCH')
                                <button class="btn btn-sm btn-light border" type="submit" title="{{ $item->aktif ? 'Sembunyikan' : 'Aktifkan' }}"><i class="bi {{ $item->aktif ? 'bi-eye-slash' : 'bi-eye' }}"></i></button>
                            </form>
                            <form method="POST" action="{{ route('admin.produk.destroy',$item) }}" onsubmit="return confirm('Hapus produk ini?')" class="d-inline">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-light border text-danger" type="submit"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center py-5">
                        <i class="bi bi-box-seam fs-1 text-muted mb-2 d-block"></i>
                        <strong class="text-dark">Belum ada produk</strong>
                        <div class="text-muted small mt-1">Klik Tambah Produk untuk memulai.</div>
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">{{ $produk->links() }}</div>

<div class="modal fade" id="modalProdukCreate" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <form method="POST" action="{{ route('admin.produk.store') }}" enctype="multipart/form-data" class="modal-content border-0 shadow-lg rounded-4">
            @csrf
            <div class="modal-header border-bottom p-4 bg-white">
                <div>
                    <h5 class="modal-title fw-bold text-dark">Tambah Produk</h5>
                    <div class="text-muted small">Input produk baru ke sistem.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            
            <div class="modal-body p-4 p-md-5" style="background-color: #f9fafb;">
                @include('admin.produk._form', ['produk' => new \App\Models\Produk()])
            </div>
            
            <div class="modal-footer border-top p-4 bg-white">
                <button class="btn btn-light border fw-medium px-4" type="button" data-bs-dismiss="modal">Batal</button>
                <button class="btn fw-bold px-4 text-white" type="submit" style="background: var(--brand-color, #dfba68);">Simpan Produk</button>
            </div>
        </form>
    </div>
</div>

@foreach($produk as $item)
<div class="modal fade" id="modalProdukEdit{{ $item->id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <form method="POST" action="{{ route('admin.produk.update',$item) }}" enctype="multipart/form-data" class="modal-content border-0 shadow-lg rounded-4">
            @csrf @method('PUT')
            <div class="modal-header border-bottom p-4 bg-white">
                <div>
                    <h5 class="modal-title fw-bold text-dark">Edit: {{ $item->nama }}</h5>
                    <div class="text-muted small">Perbarui data produk tahu.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            
            <div class="modal-body p-4 p-md-5" style="background-color: #f9fafb;">
                @include('admin.produk._form', ['produk' => $item])
            </div>
            
            <div class="modal-footer border-top p-4 bg-white">
                <button class="btn btn-light border fw-medium px-4" type="button" data-bs-dismiss="modal">Batal</button>
                <button class="btn fw-bold px-4 text-white" type="submit" style="background: var(--brand-color, #dfba68);">Perbarui Data</button>
            </div>
        </form>
    </div>
</div>
@endforeach
@endsection