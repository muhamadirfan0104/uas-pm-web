@extends('layouts.admin')
@section('title', 'Manajemen Stok - SiTahu')

@section('content')
<style>
    /* Styling Metrik & Layout */
    .stat-value { font-size: 1.85rem; font-weight: 800; letter-spacing: -0.03em; color: #111827; }
    .stat-label { font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280; }
    .stat-icon-box { width: 48px; height: 48px; border-radius: 0.5rem; background-color: #f3f4f6; color: #4b5563; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; }

    /* Styling Tabel & Kontrol */
    .table-enterprise th { border-bottom: 2px solid #e5e7eb; color: #6b7280; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; padding: 1rem 1.25rem; font-weight: 600; }
    .table-enterprise td { vertical-align: middle; padding: 1rem 1.25rem; border-bottom: 1px solid #f3f4f6; color: #111827; }
    .table-enterprise tbody tr:hover { background-color: #f9fafb; }
    
    .search-bar-modern { background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 0.75rem; transition: all 0.2s; }
    .search-bar-modern:focus-within { background-color: #ffffff; border-color: var(--brand-color, #dfba68); box-shadow: 0 0 0 4px rgba(223, 186, 104, 0.15); }
    .search-bar-modern input { background: transparent; border: none; box-shadow: none; outline: none; }

    /* List Riwayat dalam Modal */
    .history-item { transition: background-color 0.15s ease; border-bottom: 1px solid #e5e7eb; padding: 1.25rem; }
    .history-item:last-child { border-bottom: none; }
    .history-item:hover { background-color: #f9fafb; }
    
    /* Tombol Outline E-commerce */
    .btn-outline-ecommerce { border: 1px solid #d1d5db; color: #374151; background: #fff; font-weight: 500; transition: all 0.2s; }
    .btn-outline-ecommerce:hover { background: #f3f4f6; color: #111827; border-color: #d1d5db; }
</style>

<div class="d-flex flex-column flex-md-row align-items-md-end justify-content-between gap-3 mb-4">
    <div>
        <h1 class="h4 text-title mb-1 fw-bold text-dark">Manajemen Stok</h1>
        <p class="text-muted small mb-0">Pantau dan kelola ketersediaan produk Anda.</p>
    </div>
    <div>
        <button class="btn shadow-sm fw-bold px-4 d-flex align-items-center gap-2" type="button" data-bs-toggle="modal" data-bs-target="#modalRiwayatGlobal" style="background: var(--brand-color, #dfba68); color: #fff;">
            <i class="bi bi-clock-history"></i> Riwayat Perubahan Stok
        </button>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card h-100 border-0 shadow-sm rounded-3">
            <div class="card-body p-4 d-flex justify-content-between">
                <div>
                    <div class="stat-label mb-1">Total Produk</div>
                    <div class="stat-value mb-2">{{ $stats['total'] }}</div>
                    <span class="badge bg-light text-secondary border rounded-pill fw-medium">SKU Terdaftar</span>
                </div>
                <div class="stat-icon-box"><i class="bi bi-box-seam"></i></div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card h-100 border-0 shadow-sm rounded-3">
            <div class="card-body p-4 d-flex justify-content-between">
                <div>
                    <div class="stat-label mb-1">Stok Aman</div>
                    <div class="stat-value mb-2">{{ $stats['aman'] }}</div>
                    <span class="badge bg-success-subtle text-success-emphasis rounded-pill fw-medium">Kondisi Normal</span>
                </div>
                <div class="stat-icon-box bg-success-subtle text-success"><i class="bi bi-check-circle"></i></div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card h-100 border-0 shadow-sm rounded-3">
            <div class="card-body p-4 d-flex justify-content-between">
                <div>
                    <div class="stat-label mb-1">Stok Menipis</div>
                    <div class="stat-value mb-2">{{ $stats['menipis'] }}</div>
                    <span class="badge bg-warning-subtle text-warning-emphasis rounded-pill fw-medium">Tersisa 1-20 Unit</span>
                </div>
                <div class="stat-icon-box bg-warning-subtle text-warning-emphasis"><i class="bi bi-exclamation-triangle"></i></div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card h-100 border-0 shadow-sm rounded-3">
            <div class="card-body p-4 d-flex justify-content-between">
                <div>
                    <div class="stat-label mb-1">Stok Habis</div>
                    <div class="stat-value mb-2">{{ $stats['habis'] }}</div>
                    <span class="badge bg-danger-subtle text-danger-emphasis rounded-pill fw-medium">Kosong (0)</span>
                </div>
                <div class="stat-icon-box bg-danger-subtle text-danger"><i class="bi bi-x-octagon"></i></div>
            </div>
        </div>
    </div>
</div>

<div class="card border border-light shadow-sm rounded-4 overflow-hidden mb-4">
    <div class="bg-white border-bottom p-3 p-md-4">
        <form id="page-filter" method="GET">
            <div class="row g-3 align-items-center">
                <div class="col-12 col-lg">
                    <div class="search-bar-modern d-flex align-items-center px-3 py-1">
                        <i class="bi bi-search text-muted"></i>
                        <input class="form-control px-2 py-2" name="q" value="{{ request('q') }}" placeholder="Cari produk untuk diupdate...">
                    </div>
                </div>
                <div class="col-8 col-md-4 col-lg-3">
                    <select class="form-select bg-light border-light fw-medium" name="filter" style="border-radius: 0.75rem; min-height: 46px;">
                        <option value="">Semua Kondisi</option>
                        <option value="menipis" @selected(request('filter')==='menipis')>Stok Menipis</option>
                        <option value="habis" @selected(request('filter')==='habis')>Stok Habis</option>
                    </select>
                </div>
                <div class="col-4 col-md-auto">
                    <button class="btn btn-dark w-100 fw-medium px-4" type="submit" style="border-radius: 0.75rem; min-height: 46px;">Saring</button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-responsive bg-white">
        <table class="table table-enterprise table-borderless mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Informasi Produk</th>
                    <th>Harga Jual</th>
                    <th>Status Stok</th>
                    <th class="pe-4 text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($produk as $item)
                <tr>
                    <td class="ps-4">
                        <strong class="d-block text-dark mb-1" style="font-size: 0.95rem;">{{ $item->nama }}</strong>
                        <span class="text-muted small">ID: #{{ str_pad($item->id, 4, '0', STR_PAD_LEFT) }}</span>
                    </td>
                    <td><strong class="text-dark">{{ $rupiah($item->harga) }}</strong></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <strong class="fs-6 text-dark">{{ $item->stok }}</strong>
                            <span class="badge rounded-pill fw-medium {{ $item->stok <= 0 ? 'bg-danger-subtle text-danger-emphasis' : ($item->stok <= 20 ? 'bg-warning-subtle text-warning-emphasis' : 'bg-success-subtle text-success-emphasis') }}">
                                {{ $item->stok <= 0 ? 'Habis' : ($item->stok <= 20 ? 'Menipis' : 'Aman') }}
                            </span>
                        </div>
                    </td>
                    <td class="pe-4 text-end">
                        <button class="btn btn-sm btn-outline-ecommerce rounded-3 px-3 py-1" type="button" data-bs-toggle="modal" data-bs-target="#modalUpdateStok{{ $item->id }}">
                            <i class="bi bi-plus-slash-minus me-1"></i> Update Stok
                        </button>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" class="text-center py-5">
                        <i class="bi bi-box-seam fs-2 text-muted mb-2 d-block"></i>
                        <strong class="text-dark">Tidak ada produk ditemukan.</strong>
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($produk->hasPages())
        <div class="card-footer bg-white border-top p-3">{{ $produk->links() }}</div>
    @endif
</div>


@foreach($produk as $item)
<div class="modal fade" id="modalUpdateStok{{ $item->id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" action="{{ route('admin.stok.update', $item) }}" class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            @csrf @method('PATCH')
            
            <div class="modal-header bg-light border-bottom p-4">
                <div>
                    <h5 class="modal-title fw-bold text-dark mb-1">Update Stok</h5>
                    <p class="text-muted small mb-0">{{ $item->nama }}</p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            
            <div class="modal-body p-4">
                <div class="d-flex justify-content-between align-items-center p-3 rounded-3 mb-4" style="background: var(--brand-active-bg, #fbf1d4); border: 1px solid var(--brand-color, #dfba68);">
                    <span class="fw-semibold text-dark">Sisa Stok Saat Ini</span>
                    <strong class="fs-3 lh-1 text-dark">{{ $item->stok }}</strong>
                </div>

                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label fw-bold small text-secondary">Jenis Pembaruan</label>
                        <select class="form-select bg-light" name="tipe" required>
                            <option value="tambah">Penambahan (+)</option>
                            <option value="kurang">Pengurangan (-)</option>
                            <option value="penyesuaian">Set/Sesuaikan Menjadi (=)</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-bold small text-secondary">Jumlah</label>
                        <input class="form-control bg-light form-control-lg" type="number" min="0" name="jumlah" placeholder="Masukkan angka..." required>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-bold small text-secondary">Catatan (Opsional)</label>
                        <input class="form-control bg-light" name="catatan" placeholder="Misal: Barang masuk dari supplier, Rusak, dll">
                    </div>
                </div>
            </div>
            
            <div class="modal-footer border-top bg-light p-3">
                <button class="btn btn-light border fw-medium" type="button" data-bs-dismiss="modal">Batal</button>
                <button class="btn fw-bold px-4 text-white" type="submit" style="background: var(--brand-color, #dfba68);">Simpan Pembaruan</button>
            </div>
        </form>
    </div>
</div>
@endforeach


<div class="modal fade" id="modalRiwayatGlobal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg rounded-4">
            
            <div class="modal-header border-bottom p-4 d-flex flex-column align-items-stretch gap-3 bg-white">
                <div class="d-flex justify-content-between align-items-center w-100">
                    <div>
                        <h5 class="modal-title fw-bold text-dark mb-1">Riwayat Pergerakan Stok</h5>
                        <p class="text-muted small mb-0">Catatan aktivitas stok masuk dan keluar.</p>
                    </div>
                    <button type="button" class="btn-close mb-auto" data-bs-dismiss="modal" aria-label="Tutup"></button>
                </div>
                
                <div class="search-bar-modern d-flex align-items-center px-3 py-2 w-100">
                    <i class="bi bi-search text-muted"></i>
                    <input type="text" id="filterRiwayatInstan" class="form-control px-2" placeholder="Ketik nama produk atau catatan untuk mencari riwayat...">
                </div>
            </div>
            
            <div class="modal-body p-0 bg-white" id="containerRiwayat">
                @forelse($riwayat as $log)
                    <div class="history-item js-riwayat-item">
                        <div class="d-flex justify-content-between align-items-start gap-3">
                            <div class="flex-grow-1 min-w-0">
                                <strong class="d-block text-dark mb-1 js-riwayat-title" style="font-size: 0.95rem;">
                                    {{ $log->produk?->nama ?? 'Produk Dihapus' }}
                                </strong>
                                <div class="text-muted d-flex align-items-center flex-wrap gap-2 mb-1 js-riwayat-desc" style="font-size: 0.8rem;">
                                    <span class="fw-medium text-dark bg-light px-2 py-1 rounded">{{ $statusLabel($log->tipe) }}</span>
                                    <span>•</span>
                                    <span>{{ $log->catatan ?? 'Tanpa catatan' }}</span>
                                </div>
                                <div class="text-secondary" style="font-size: 0.75rem;">
                                    <i class="bi bi-calendar3 me-1"></i> {{ $log->created_at->format('d M Y, H:i') }}
                                </div>
                            </div>
                            
                            <div class="text-end flex-shrink-0">
                                <div class="badge rounded-pill px-3 py-2 fs-6 shadow-sm {{ $log->perubahan > 0 ? 'bg-success-subtle text-success-emphasis' : ($log->perubahan < 0 ? 'bg-danger-subtle text-danger-emphasis' : 'bg-light text-secondary border') }}">
                                    {{ $log->perubahan > 0 ? '+' : '' }}{{ $log->perubahan }}
                                </div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="p-5 text-center">
                        <i class="bi bi-clipboard-x fs-1 text-muted mb-3 d-block"></i>
                        <strong class="text-dark">Belum ada riwayat tercatat.</strong>
                    </div>
                @endforelse
            </div>
            
            <div class="modal-footer bg-light border-top p-3 justify-content-center">
                <span class="text-muted small">Menampilkan data riwayat stok terbaru.</span>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('filterRiwayatInstan');
        const items = document.querySelectorAll('.js-riwayat-item');

        if(searchInput) {
            searchInput.addEventListener('keyup', function(e) {
                const term = e.target.value.toLowerCase();
                
                items.forEach(function(item) {
                    const title = item.querySelector('.js-riwayat-title').textContent.toLowerCase();
                    const desc = item.querySelector('.js-riwayat-desc').textContent.toLowerCase();
                    
                    if (title.includes(term) || desc.includes(term)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        }
    });
</script>
@endpush