<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pembayaran;
use App\Models\Pesanan;
use App\Models\Produk;
use App\Models\Ulasan;
use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $today = Carbon::today();
        $startOfMonth = Carbon::now()->startOfMonth();

        $stats = [
            'total_penjualan' => Pembayaran::where('status', 'dibayar')->sum('jumlah'),
            'penjualan_hari_ini' => Pembayaran::where('status', 'dibayar')->whereDate('created_at', $today)->sum('jumlah'),
            'penjualan_bulan_ini' => Pembayaran::where('status', 'dibayar')->where('created_at', '>=', $startOfMonth)->sum('jumlah'),
            'total_pesanan' => Pesanan::count(),
            'pesanan_hari_ini' => Pesanan::whereDate('tanggal_pesanan', $today)->count(),
            'pesanan_diproses' => Pesanan::where('status', 'diproses')->count(),
            'menunggu_pembayaran' => Pesanan::where('status_pembayaran', 'menunggu_pembayaran')->count(),
            'produk_aktif' => Produk::where('aktif', true)->count(),
            'stok_menipis' => Produk::where('stok', '>', 0)->where('stok', '<=', 20)->count(),
            'stok_habis' => Produk::where('stok', '<=', 0)->count(),
            'total_pembeli' => User::where('role', 'pembeli')->count(),
            'total_ulasan' => Ulasan::count(),
        ];

        $produkTerlaris = Produk::withSum('itemPesanan as total_terjual', 'jumlah')
            ->orderByDesc('total_terjual')
            ->limit(5)
            ->get();

        $pesananTerbaru = Pesanan::with(['user', 'pembayaran'])
            ->latest('tanggal_pesanan')
            ->limit(6)
            ->get();

        $penjualanMingguan = collect(range(6, 0))->map(function ($day) {
            $tanggal = Carbon::today()->subDays($day);
            return [
                'label' => $tanggal->translatedFormat('d M'),
                'total' => (float) Pembayaran::where('status', 'dibayar')->whereDate('created_at', $tanggal)->sum('jumlah'),
            ];
        });

        $maxPenjualan = max($penjualanMingguan->max('total'), 1);

        return view('admin.dashboard', compact('stats', 'produkTerlaris', 'pesananTerbaru', 'penjualanMingguan', 'maxPenjualan'));
    }
}
