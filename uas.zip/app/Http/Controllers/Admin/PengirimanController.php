<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PengaturanToko;
use App\Models\Pengiriman;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PengirimanController extends Controller
{
    public function index(Request $request): View
    {
        $query = Pengiriman::with(['pesanan.user'])->latest();

        if ($request->filled('metode')) {
            $query->where('metode', $request->metode);
        }

        if ($request->filled('status')) {
            $query->where('status_pengiriman', $request->status);
        }

        $pengiriman = $query->paginate(12)->withQueryString();
        $pengaturan = PengaturanToko::utama();

        return view('admin.pengiriman.index', compact('pengiriman', 'pengaturan'));
    }

    public function updateStatus(Request $request, Pengiriman $pengiriman): RedirectResponse
    {
        $data = $request->validate([
            'status_pengiriman' => ['required', 'in:siap_diambil,dalam_pengantaran,selesai'],
        ]);

        $pengiriman->update($data);

        $statusPesanan = match ($data['status_pengiriman']) {
            'siap_diambil' => 'siap_diambil',
            'dalam_pengantaran' => 'dalam_pengantaran',
            'selesai' => 'selesai',
        };

        $pengiriman->pesanan?->update(['status' => $statusPesanan]);

        return back()->with('success', 'Status pengiriman berhasil diperbarui.');
    }
}
